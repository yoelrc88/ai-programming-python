## Contact:

Yoel Ramos Castillo
yoelrc88@gmail.com
https://github.com/yoelrc88

### This files can also be found and tested here:

https://github.com/yoelrc88/ai-programming-python/tree/master/6-create-your-own-classifier-project

